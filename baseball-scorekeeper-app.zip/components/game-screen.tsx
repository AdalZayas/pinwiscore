'use client'

import { useGameStore } from '@/lib/game-store'
import { Card, CardContent } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Switch } from '@/components/ui/switch'
import { Label } from '@/components/ui/label'
import { Scoreboard } from './scoreboard'
import { BaseballDiamond } from './baseball-diamond'
import { SimpleMode } from './simple-mode'
import { AdvancedMode } from './advanced-mode'
import { Scorecard } from './scorecard'
import { LineupView } from './lineup-view'
import { PlayByPlay } from './play-by-play'
import { StatsView } from './stats-view'
import { BatterTransition } from './batter-transition'

export function GameScreen() {
  const { mode, setMode, myTeam, opponentName, getTotalScore } = useGameStore()

  const myScore = getTotalScore('myTeam')
  const opponentScore = getTotalScore('opponent')

  return (
    <div className="min-h-screen bg-background pb-4">
      {/* Batter Transition Animation */}
      <BatterTransition />

      {/* Header with scores */}
      <div className="sticky top-0 z-10 bg-background/95 backdrop-blur border-b">
        <div className="max-w-lg mx-auto p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="text-center">
                <div className="text-xs text-muted-foreground uppercase tracking-wide">
                  {myTeam.name || 'My Team'}
                </div>
                <div className="text-3xl font-bold font-mono">{myScore}</div>
              </div>
              <div className="text-muted-foreground text-lg">-</div>
              <div className="text-center">
                <div className="text-xs text-muted-foreground uppercase tracking-wide">
                  {opponentName || 'Opponent'}
                </div>
                <div className="text-3xl font-bold font-mono">{opponentScore}</div>
              </div>
            </div>
            <BaseballDiamond />
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="max-w-lg mx-auto px-4">
        <Tabs defaultValue="score" className="space-y-4">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="score">Score</TabsTrigger>
            <TabsTrigger value="scorecard">Card</TabsTrigger>
            <TabsTrigger value="lineup">Lineup</TabsTrigger>
            <TabsTrigger value="plays">Plays</TabsTrigger>
            <TabsTrigger value="stats">Stats</TabsTrigger>
          </TabsList>

          <TabsContent value="score" className="space-y-4">
            {/* Mode Toggle */}
            <div className="flex items-center justify-between">
              <Label htmlFor="mode-toggle" className="text-sm text-muted-foreground">
                {mode === 'simple' ? 'Simple Mode' : 'Advanced Mode'}
              </Label>
              <div className="flex items-center gap-2">
                <span className="text-xs text-muted-foreground">Simple</span>
                <Switch
                  id="mode-toggle"
                  checked={mode === 'advanced'}
                  onCheckedChange={(checked) => setMode(checked ? 'advanced' : 'simple')}
                />
                <span className="text-xs text-muted-foreground">Advanced</span>
              </div>
            </div>

            {/* Scoreboard */}
            <Card>
              <CardContent className="p-2">
                <Scoreboard />
              </CardContent>
            </Card>

            {/* Mode-specific controls */}
            {mode === 'simple' ? <SimpleMode /> : <AdvancedMode />}
          </TabsContent>

          <TabsContent value="scorecard">
            <Scorecard />
          </TabsContent>

          <TabsContent value="lineup">
            <LineupView />
          </TabsContent>

          <TabsContent value="plays">
            <PlayByPlay />
          </TabsContent>

          <TabsContent value="stats">
            <StatsView />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
