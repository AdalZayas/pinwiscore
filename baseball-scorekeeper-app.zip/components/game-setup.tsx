'use client'

import { useState } from 'react'
import { useGameStore } from '@/lib/game-store'
import { Player, samplePlayers, POSITIONS, PositionAbbrev } from '@/lib/types'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { Plus, Trash2, Users } from 'lucide-react'

interface PlayerFormData {
  name: string
  jerseyNumber: string
  position: PositionAbbrev
}

export function GameSetup() {
  const {
    awayTeam,
    homeTeam,
    totalInnings,
    setTeamName,
    setHomeTeam,
    setTotalInnings,
    setPlayers,
    startGame,
  } = useGameStore()

  const [awayPlayers, setAwayPlayers] = useState<Player[]>([])
  const [homePlayers, setHomePlayers] = useState<Player[]>([])
  const [newPlayer, setNewPlayer] = useState<{ away: PlayerFormData; home: PlayerFormData }>({
    away: { name: '', jerseyNumber: '', position: 'CF' },
    home: { name: '', jerseyNumber: '', position: 'CF' },
  })

  const addPlayer = (team: 'away' | 'home') => {
    const data = newPlayer[team]
    if (!data.name.trim()) return

    const players = team === 'away' ? awayPlayers : homePlayers
    const setPlayerList = team === 'away' ? setAwayPlayers : setHomePlayers

    const player: Player = {
      id: crypto.randomUUID(),
      name: data.name.trim(),
      jerseyNumber: data.jerseyNumber || '0',
      position: data.position,
      battingOrder: players.length + 1,
    }

    setPlayerList([...players, player])
    setNewPlayer({
      ...newPlayer,
      [team]: { name: '', jerseyNumber: '', position: 'CF' },
    })
  }

  const removePlayer = (team: 'away' | 'home', playerId: string) => {
    const players = team === 'away' ? awayPlayers : homePlayers
    const setPlayerList = team === 'away' ? setAwayPlayers : setHomePlayers

    const updated = players
      .filter((p) => p.id !== playerId)
      .map((p, i) => ({ ...p, battingOrder: i + 1 }))

    setPlayerList(updated)
  }

  const loadSampleTeam = (team: 'away' | 'home') => {
    const sample = team === 'away' ? samplePlayers.pinwinos : samplePlayers.desechables
    const setPlayerList = team === 'away' ? setAwayPlayers : setHomePlayers
    const setName = team === 'away' ? 'Pinwinos' : 'Desechables'

    setPlayerList(sample.map((p) => ({ ...p, id: crypto.randomUUID() })))
    setTeamName(team, setName)
  }

  const handleStartGame = () => {
    if (awayPlayers.length < 9 || homePlayers.length < 9) {
      alert('Each team needs at least 9 players')
      return
    }

    setPlayers('away', awayPlayers)
    setPlayers('home', homePlayers)
    startGame()
  }

  const canStart = awayTeam.name && homeTeam.name && awayPlayers.length >= 9 && homePlayers.length >= 9

  return (
    <div className="min-h-screen bg-background p-4 pb-24">
      <div className="mx-auto max-w-4xl space-y-6">
        <div className="text-center space-y-2">
          <h1 className="text-3xl font-bold text-foreground">Dugout Scorekeeper</h1>
          <p className="text-muted-foreground">Set up your game</p>
        </div>

        {/* Game Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Game Settings</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="awayTeam">Away Team</Label>
                <Input
                  id="awayTeam"
                  placeholder="Team name"
                  value={awayTeam.name}
                  onChange={(e) => setTeamName('away', e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="homeTeam">Home Team</Label>
                <Input
                  id="homeTeam"
                  placeholder="Team name"
                  value={homeTeam.name}
                  onChange={(e) => setTeamName('home', e.target.value)}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>Number of Innings</Label>
              <RadioGroup
                value={totalInnings.toString()}
                onValueChange={(v) => setTotalInnings(parseInt(v))}
                className="flex gap-4"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="7" id="innings-7" />
                  <Label htmlFor="innings-7" className="cursor-pointer">7 Innings</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="9" id="innings-9" />
                  <Label htmlFor="innings-9" className="cursor-pointer">9 Innings</Label>
                </div>
              </RadioGroup>
            </div>
          </CardContent>
        </Card>

        {/* Team Lineups */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {(['away', 'home'] as const).map((team) => {
            const players = team === 'away' ? awayPlayers : homePlayers
            const teamName = team === 'away' ? awayTeam.name : homeTeam.name
            const playerData = newPlayer[team]

            return (
              <Card key={team}>
                <CardHeader className="flex flex-row items-center justify-between">
                  <CardTitle className="text-lg">
                    {teamName || (team === 'away' ? 'Away' : 'Home')} Lineup
                  </CardTitle>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => loadSampleTeam(team)}
                    className="text-xs"
                  >
                    <Users className="mr-1 h-3 w-3" />
                    Load Sample
                  </Button>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Add Player Form */}
                  <div className="flex flex-col gap-2">
                    <div className="flex gap-2">
                      <Input
                        placeholder="Player name"
                        value={playerData.name}
                        onChange={(e) =>
                          setNewPlayer({
                            ...newPlayer,
                            [team]: { ...playerData, name: e.target.value },
                          })
                        }
                        className="flex-1"
                      />
                      <Input
                        placeholder="#"
                        value={playerData.jerseyNumber}
                        onChange={(e) =>
                          setNewPlayer({
                            ...newPlayer,
                            [team]: { ...playerData, jerseyNumber: e.target.value },
                          })
                        }
                        className="w-16"
                      />
                    </div>
                    <div className="flex gap-2">
                      <Select
                        value={playerData.position}
                        onValueChange={(v) =>
                          setNewPlayer({
                            ...newPlayer,
                            [team]: { ...playerData, position: v as PositionAbbrev },
                          })
                        }
                      >
                        <SelectTrigger className="flex-1">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {Object.values(POSITIONS).map((pos) => (
                            <SelectItem key={pos} value={pos}>
                              {pos}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <Button onClick={() => addPlayer(team)} size="icon">
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>

                  {/* Players Table */}
                  {players.length > 0 && (
                    <div className="rounded-md border overflow-hidden">
                      <Table>
                        <TableHeader>
                          <TableRow className="bg-muted/50">
                            <TableHead className="w-12">#</TableHead>
                            <TableHead>Name</TableHead>
                            <TableHead className="w-16">Pos</TableHead>
                            <TableHead className="w-12"></TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {players.map((player) => (
                            <TableRow key={player.id}>
                              <TableCell className="font-mono text-muted-foreground">
                                {player.battingOrder}
                              </TableCell>
                              <TableCell>
                                <span className="font-medium">{player.name}</span>
                                <span className="text-muted-foreground ml-2">
                                  #{player.jerseyNumber}
                                </span>
                              </TableCell>
                              <TableCell>
                                <span className="inline-flex items-center justify-center rounded bg-secondary px-2 py-0.5 text-xs font-medium">
                                  {player.position}
                                </span>
                              </TableCell>
                              <TableCell>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8 text-muted-foreground hover:text-destructive"
                                  onClick={() => removePlayer(team, player.id)}
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  )}

                  <p className="text-xs text-muted-foreground text-center">
                    {players.length}/9 players minimum
                  </p>
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* Start Game Button */}
        <div className="fixed bottom-0 left-0 right-0 p-4 bg-background/95 backdrop-blur border-t">
          <div className="mx-auto max-w-4xl">
            <Button
              onClick={handleStartGame}
              disabled={!canStart}
              className="w-full h-14 text-lg font-semibold"
              size="lg"
            >
              Start Game
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
