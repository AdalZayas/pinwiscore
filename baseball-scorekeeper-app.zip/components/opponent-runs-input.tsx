'use client'

import { useState } from 'react'
import { useGameStore } from '@/lib/game-store'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Minus, Plus } from 'lucide-react'

export function OpponentRunsInput() {
  const { opponentName, currentInning, isMyTeamHome, recordOpponentRuns, getTotalScore } = useGameStore()
  const [runs, setRuns] = useState(0)

  const handleSubmit = () => {
    recordOpponentRuns(runs)
    setRuns(0)
  }

  const myScore = getTotalScore('myTeam')
  const opponentScore = getTotalScore('opponent')

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <Card className="w-full max-w-sm">
        <CardHeader className="text-center space-y-2">
          <div className="text-sm text-muted-foreground uppercase tracking-wide">
            {isMyTeamHome ? 'Top' : 'Bottom'} of Inning {currentInning}
          </div>
          <CardTitle className="text-xl">
            How many runs did {opponentName} score?
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Current Score Display */}
          <div className="flex items-center justify-center gap-6 py-4 bg-muted/50 rounded-lg">
            <div className="text-center">
              <div className="text-xs text-muted-foreground uppercase tracking-wide">You</div>
              <div className="text-2xl font-bold font-mono">{myScore}</div>
            </div>
            <div className="text-muted-foreground">-</div>
            <div className="text-center">
              <div className="text-xs text-muted-foreground uppercase tracking-wide">{opponentName}</div>
              <div className="text-2xl font-bold font-mono">{opponentScore}</div>
            </div>
          </div>

          {/* Runs Input */}
          <div className="flex items-center justify-center gap-4">
            <Button
              variant="outline"
              size="icon"
              className="h-14 w-14 rounded-full"
              onClick={() => setRuns(Math.max(0, runs - 1))}
              disabled={runs === 0}
            >
              <Minus className="h-6 w-6" />
            </Button>

            <div className="relative">
              <Input
                type="number"
                min="0"
                max="99"
                value={runs}
                onChange={(e) => setRuns(Math.max(0, parseInt(e.target.value) || 0))}
                className="w-24 h-20 text-center text-4xl font-bold font-mono"
              />
            </div>

            <Button
              variant="outline"
              size="icon"
              className="h-14 w-14 rounded-full"
              onClick={() => setRuns(runs + 1)}
            >
              <Plus className="h-6 w-6" />
            </Button>
          </div>

          {/* Quick Select */}
          <div className="grid grid-cols-4 gap-2">
            {[0, 1, 2, 3].map((n) => (
              <Button
                key={n}
                variant={runs === n ? 'default' : 'outline'}
                className="h-12 text-lg font-mono"
                onClick={() => setRuns(n)}
              >
                {n}
              </Button>
            ))}
          </div>

          {/* Submit Button */}
          <Button onClick={handleSubmit} className="w-full h-14 text-lg font-semibold" size="lg">
            Continue
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
